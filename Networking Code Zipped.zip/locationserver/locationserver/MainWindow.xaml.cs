﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace locationserver
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool serverRun = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        public void start_btn_Click(object sender, RoutedEventArgs e)
        {
            if (serverRun)
            {
                return;
            }
            new Thread(Program.runServer).Start();
            MessageBox.Show("Server is Running");
            serverRun = true;
        }

        private void stop_btn_Click(object sender, RoutedEventArgs e)
        {
            if (!serverRun)
            {
                return;
            }
            Program.listener.Stop();
            MessageBox.Show("Server is not Running");
            serverRun = false;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (serverRun)
            {
                Program.listener.Stop();
            }
        }
    }
}
