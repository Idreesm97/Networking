﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Net;

namespace locationserver
{
    class Program
    {
        #region start up
        /*1**/
        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern bool FreeConsole();
        public static TcpListener listener;
        [STAThread]


        public static int Main(string[] args)
        {
            if (!args.Contains("-w"))
            {
                runServer();
                return 0;
            }
            else
                FreeConsole();
            var app = new App();
            return app.Run();
        }

        static Dictionary<string, string> userStore = new Dictionary<string, string>();
        #endregion
        public static void runServer()
        {

            Socket connection;
            Handler RequestHandler;

            try
            {
                // gets connection when the compiler enters the while loop
                int portNum = 43;
                listener = new TcpListener(IPAddress.Any, portNum);
                listener.Start(); // Starts listening
                Console.WriteLine("Server started Listening");

                while (true)
                {
                    // gets connection
                    // connection going to be accepted
                    connection = listener.AcceptSocket(); // listens out for data to read in.
                    RequestHandler = new Handler();

                    Thread t = new Thread(() => RequestHandler.doRequest(connection));
                    t.Start();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
            }
        }
        class Handler
        {

            public void doRequest(Socket connection)
            {
                NetworkStream socketStream;
                socketStream = new NetworkStream(connection);
                Console.WriteLine("Connection Received");

                try
                {


                    socketStream.WriteTimeout = 1000;
                    socketStream.ReadTimeout = 1000;
                    StreamWriter sw = new StreamWriter(socketStream);
                    StreamReader sr = new StreamReader(socketStream);
                    StringBuilder stringBuilder = new StringBuilder();
                    sw.AutoFlush = true;

                    //Lab4 

                    List<string> dataInfo = new List<string>();
                    string host = "whois.net.dcs.hull.ac.uk";
                    //string host = "localhost";

                    while (sr.Peek() >= 0)
                    {
                        stringBuilder.Append(sr.ReadLine() + " ");
                    }
                    string j = stringBuilder.ToString();
                    if (j.Length > 0)
                    {
                        j = j.Remove(j.Length - 1);
                    }


                    //infoStore.RemoveAt(infoStore.Count - 1);

                    dataInfo.AddRange(j.Split());

                    //if (!dataInfo[0].EndsWith("HTTP/1.0") && !dataInfo[0].EndsWith("HTTP/1.1") && dataInfo[0].StartsWith("GET") || dataInfo[0].StartsWith("PUT"))
                    //{
                    if (dataInfo[0] == "GET")
                    {

                        if (dataInfo[1].Contains("/"))
                        {
                            dataInfo[1] = dataInfo[1].Remove(0, 1);
                        }

                        if (j.Contains("HTTP/1.0"))
                        {
                            dataInfo[1] = dataInfo[1].Remove(0, 1);

                            if (userStore.ContainsKey(dataInfo[1]))
                            {
                                sw.WriteLine("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n" + userStore[dataInfo[1]] + "\r\n");
                            }
                            else
                            {
                                sw.WriteLine("HTTP/1.0 404 Not Found \r\nContent-Type: text/plain\r\n\r\n");
                            }
                        }
                        else if (j.Contains("HTTP/1.1"))
                        {
                            dataInfo[1] = dataInfo[1].Remove(0, 6);
                            if (userStore.ContainsKey(dataInfo[1]))
                            {
                                sw.WriteLine("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n" + userStore[dataInfo[1]] + "\r\n");
                            }
                            else
                            {
                                sw.WriteLine("HTTP/1.1 404 Not Found \r\nContent-Type: text/plain\r\n\r\n");
                            }
                        }
                        else if (userStore.ContainsKey(dataInfo[1]))
                        {
                            sw.WriteLine("HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n" + userStore[dataInfo[1]] + "\r\n");

                        }
                        else
                        {
                            sw.WriteLine("HTTP/0.9 404 Not Found \r\nContent-Type: text/plain\r\n\r\n");
                        }
                    }

                    else if (dataInfo[0] == "POST" || dataInfo[0] == "PUT")
                    {

                        if (dataInfo[1].Contains("/"))
                        {
                            dataInfo[1] = dataInfo[1].Remove(0, 1);
                        }
                        if (j.Contains("HTTP/1.1"))
                        {
                            string username = "";
                            string location = "";
                            dataInfo[8] = dataInfo[8].Remove(0, 5);
                            int index = dataInfo[8].IndexOf('&');
                            dataInfo[8] = dataInfo[8].Remove(index, 9);
                            dataInfo[8] = dataInfo[8].Replace('=', ' ');
                            string[] combiner = dataInfo[8].Split(' ');
                            username = combiner[0];
                            location = combiner[1];

                            if (dataInfo.Count > 9)
                            {
                                for (int i = 9; i < dataInfo.Count; i++)
                                {
                                    location += " " + dataInfo[i];
                                }
                            }

                            if (userStore.ContainsKey(username))
                            {
                                userStore[username] = location;
                            }
                            else
                            {
                                userStore.Add(username, location);

                            }
                            sw.WriteLine("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        else if (j.Contains("HTTP/1.0"))
                        {
                            string username = "";
                            string location = "";

                            dataInfo[1] = dataInfo[1].Remove(0, 1);

                            for (int i = 1; i < dataInfo.Count; i++)
                            {
                                if (i == 1)
                                {
                                    username = dataInfo[i];
                                }
                                else if (dataInfo[i] == " ")
                                {
                                    dataInfo.Remove(" ");
                                    i--;
                                }
                                else if (i >= 5)
                                {
                                    location += dataInfo[i] + " ";
                                }

                            }

                            location = location.Trim();

                            if (location.Length > 0)
                            {
                                location = location.Remove(location.Length - 1);
                            }

                            if (userStore.ContainsKey(username))
                            {
                                userStore[username] = location;
                            }
                            else
                            {
                                userStore.Add(username, location);
                            }
                            sw.WriteLine("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        else
                        {
                            string username = dataInfo[1];
                            string location = dataInfo[2];
                            string locSpace = "";

                            dataInfo.RemoveAt(2);

                            if (dataInfo.Count > 3)
                            {
                                locSpace = dataInfo[2];

                                for (int x = 3; x < dataInfo.Count;)
                                {
                                    locSpace += " " + dataInfo[x];
                                    dataInfo.RemoveAt(x);
                                }
                                location = locSpace;

                            }
                            if (userStore.ContainsKey(username))
                            {
                                sw.WriteLine("HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                                userStore[username] = location;
                            }
                            else
                            {
                                sw.WriteLine("HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                                userStore.Add(username, location);

                            }
                        }
                    }
                    //}
                    else
                    {
                        Console.WriteLine("Respond received: " + j);
                        String[] sections = j.Split(new char[] { ' ' }, 2);

                        if (sections.Length == 1)// If args = 1 enteres if statement
                        {
                            if (userStore.ContainsKey(sections[0])) //Checks unique key 
                            {

                                sw.WriteLine(userStore[sections[0]]); //Outputs unique key

                            }
                            else
                            {
                                sw.WriteLine("ERROR: no entries found");
                            }

                        }
                        else if (sections.Length == 2)
                        {
                            if (userStore.ContainsKey(sections[0]))
                            {
                                userStore[sections[0]] = sections[1]; // Updates user
                                sw.WriteLine("OK\r\n");
                            }
                            else
                            {
                                userStore.Add(sections[0], sections[1]); //Adds to the dictionary
                                sw.WriteLine("OK\r\n");

                            }
                        }
                        else
                        {
                            Console.WriteLine("No Arguments given");
                            sw.WriteLine("OK\r\n");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                finally
                {
                    socketStream.Close();
                    connection.Close();
                }
            }
        }
    }
}
