﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net.Sockets;
using Location;



namespace Location
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Submit_Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int port = int.Parse(Port_TB.Text);
                TcpClient client = new TcpClient();
                client.Connect(Host_TB.Text, port);
                StreamWriter sw = new StreamWriter(client.GetStream());
                StreamReader sr = new StreamReader(client.GetStream());
                sw.AutoFlush = true;
                client.ReceiveTimeout = int.Parse(Timeout_TB.Text);
                client.SendTimeout = int.Parse(Timeout_TB.Text);


                if (whois_Checkbox.IsChecked == true)
                {

                    if (Location_TB.Text == "")
                    {
                        sw.WriteLine(Username_TB.Text);

                        MessageBox.Show(Username_TB.Text + " is " + sr.ReadToEnd());

                    }
                    else
                    {
                        sw.WriteLine(Username_TB.Text + " " + Location_TB.Text);


                        String reply = sr.ReadLine();
                        if (reply == "OK")
                        {
                            MessageBox.Show(Username_TB.Text + " location changed to be " + Username_TB.Text + "\r\n");
                        }
                        else
                        {
                            MessageBox.Show("ERROR: Unexpected response: " + reply);
                        }
                    }
                }
                    
                    if(H9RB.IsChecked == true)
                    {
                        if (Location_TB.Text == "")
                        {
                            sw.WriteLine("GET /" + Username_TB.Text + "\r\n");

                            String line = sr.ReadLine();
                            line = sr.ReadLine();
                            line = sr.ReadLine();
                            MessageBox.Show(Username_TB.Text + " is " + sr.ReadLine());
                        }
                        else
                        {
                            sw.WriteLine("PUT /" + Username_TB.Text + "\r\n" + Location_TB.Text);

                            string reply = sr.ReadLine();
                            if (reply.EndsWith("OK"))
                            {
                                MessageBox.Show(Username_TB.Text + " location changed to be " + Location_TB.Text + "\r\n");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: Unexpected response: " + reply);
                            }
                        }
                    }

                   if(H1RB.IsChecked == true)
                    {
                        if (Location_TB.Text == "")
                        {
                            sw.WriteLine("GET /?" + Username_TB.Text + " HTTP/1.0" + "\r\n" + "\r\n");
                            string line = sr.ReadLine();
                            line = sr.ReadLine();
                            line = sr.ReadLine();
                            MessageBox.Show(Username_TB.Text + " is " + sr.ReadLine());
                        }
                        else
                        {
                            int length = Location_TB.Text.Length;

                            sw.WriteLine("POST /" + Username_TB.Text + " HTTP/1.0");
                            sw.WriteLine("Content-Length: " + length);
                            sw.WriteLine();
                            sw.WriteLine(Location_TB.Text);

                            string reply = sr.ReadLine();
                            if (reply.EndsWith("OK"))
                            {
                                MessageBox.Show(Username_TB.Text + " location changed to be " + Location_TB.Text + "\r\n");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: Unexpected response: " + reply);
                            }

                        }
                    }
                    if(H0RB.IsChecked == true)
                    {
                        if (Location_TB.Text == "")
                        {
                            sw.WriteLine("GET /?name=" + Username_TB.Text + " HTTP/1.1");
                            sw.WriteLine("Host: " + Host_TB.Text);
                            sw.WriteLine();

                            if (port == 80)
                            {
                                List<string> list = new List<string>();
                                string j = "";
                                while (sr.Peek() > 0)
                                {
                                    j = sr.ReadLine().ToString();
                                    list.Add(j);
                                }
                                j = "";
                                int mid = list.IndexOf("");
                                for (int i = mid + 1; i < list.Count; i++)
                                {
                                    j = j + list[i];
                                    j = j + "\r\n";
                                }
                                MessageBox.Show(Username_TB.Text + " is " + j);

                            }
                            else
                            {
                                string lineOne = sr.ReadLine();
                                lineOne = sr.ReadLine();
                                lineOne = sr.ReadLine();
                                MessageBox.Show(Username_TB.Text + " is " + sr.ReadLine());
                            }



                        }
                        else
                        {
                            int x = 15;
                            int y = Username_TB.Text.Length;
                            int z = Location_TB.Text.Length;

                            int length = x + y + z;

                            sw.WriteLine("POST / HTTP/1.1");
                            sw.WriteLine("Host: " + Host_TB.Text);
                            sw.WriteLine("Content-Length: " + length);
                            sw.WriteLine();
                            sw.WriteLine("name=" + Username_TB.Text + "&location=" + Location_TB.Text);

                            String reply = sr.ReadLine();
                            if (reply.EndsWith("OK"))
                            {
                                MessageBox.Show(Username_TB.Text + " location changed to be " + Location_TB.Text + "\r\n");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: Unexpected response: " + reply);
                            }

                        }
                    }
            }

            catch (Exception ex )
            {
                MessageBox.Show(ex + "\r\n" + "An error has occurred");
            }
        }

        private void Port_TB_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

