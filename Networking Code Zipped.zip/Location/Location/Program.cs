﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net.Sockets;
using Location;
using System.Runtime.InteropServices;

namespace NetworkClient
{
    public static class Program
    {

        /*1**/ [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern bool FreeConsole();
        [STAThread]
        public static int Main(string[] args)
        {
            if (args != null && args.Length > 0)
            {
                try
                {

                    String host = "whois.net.dcs.hull.ac.uk";
                    int port = 43;
                    string protocol = "whois";

                    string nameValue = null;
                    string locationValue = null;

                    for (int i = 0; i < args.Length; ++i)
                    {
                        switch (args[i])
                        {
                            case "-h": host = args[++i]; break;
                            case "-p": port = int.Parse(args[++i]); break;
                            case "-h9":
                            case "-h0":
                            case "-h1": protocol = args[i]; break;
                            default:
                                if (nameValue == null)
                                {
                                    nameValue = args[i];
                                }
                                else if (locationValue == null)
                                {
                                    locationValue = args[i];
                                }
                                else
                                {
                                    Console.WriteLine("Too many arguments");
                                }

                                break;
                        }
                    }


                    if (nameValue == null)
                    {
                        Console.WriteLine("Too few arguments");

                    }



                    TcpClient client = new TcpClient();
                    client.Connect(host, port);
                    StreamWriter sw = new StreamWriter(client.GetStream());
                    StreamReader sr = new StreamReader(client.GetStream());
                    sw.AutoFlush = true;
                    client.ReceiveTimeout = 1000;
                    client.SendTimeout = 1000;


                    switch (protocol)
                    {
                        case "whois":
                            if (locationValue == null)
                            {
                                sw.WriteLine(nameValue);

                                Console.WriteLine(nameValue + " is " + sr.ReadToEnd());

                            }
                            else
                            {
                                sw.WriteLine(nameValue + " " + locationValue);


                                String reply = sr.ReadLine();
                                if (reply == "OK")
                                {
                                    Console.WriteLine(nameValue + " location changed to be " + locationValue + "\r\n");
                                }
                                else
                                {
                                    Console.WriteLine("ERROR: Unexpected response: " + reply);
                                }
                            }

                            break;

                        case "-h9":
                            if (locationValue == null)
                            {
                                sw.WriteLine("GET /" + nameValue + "\r\n");

                                string line = sr.ReadLine();
                                line = sr.ReadLine();
                                line = sr.ReadLine();
                                Console.WriteLine(nameValue + " is " + sr.ReadLine());
                            }
                            else
                            {
                                sw.WriteLine("PUT /" + nameValue + "\r\n" + locationValue);

                                String reply = sr.ReadLine();
                                if (reply.EndsWith("OK"))
                                {
                                    Console.WriteLine(nameValue + " location changed to be " + locationValue + "\r\n");
                                }
                                else
                                {
                                    Console.WriteLine("ERROR: Unexpected response: " + reply);
                                }
                            }
                            break;

                        case "-h0":
                            if (locationValue == null)
                            {
                                sw.WriteLine("GET /?" + nameValue + " HTTP/1.0" + "\r\n" + "\r\n");
                                string line = sr.ReadLine();
                                line = sr.ReadLine();
                                line = sr.ReadLine();
                                Console.WriteLine(nameValue + " is " + sr.ReadLine());
                            }
                            else
                            {
                                int length = locationValue.Length;

                                sw.WriteLine("POST /" + nameValue + " HTTP/1.0");
                                sw.WriteLine("Content-Length: " + length);
                                sw.WriteLine();
                                sw.WriteLine(locationValue);

                                string reply = sr.ReadLine();
                                if (reply.EndsWith("OK"))
                                {
                                    Console.WriteLine(nameValue + " location changed to be " + locationValue + "\r\n");
                                }
                                else
                                {
                                    Console.WriteLine("ERROR: Unexpected response: " + reply);
                                }

                            }
                            break;
                        case "-h1":
                            if (locationValue == null)
                            {
                                sw.WriteLine("GET /?name=" + nameValue + " HTTP/1.1");
                                sw.WriteLine("Host: " + host);
                                sw.WriteLine();

                                if (port == 80)
                                {
                                    List<string> list = new List<string>();
                                    string j = "";
                                    while (sr.Peek() > 0)
                                    {
                                        j = sr.ReadLine().ToString();
                                        list.Add(j);
                                    }
                                    j = "";
                                    int mid = list.IndexOf("");
                                    for (int i = mid + 1; i < list.Count; i++)
                                    {
                                        j = j + list[i];
                                        j = j + "\r\n";
                                    }
                                    Console.WriteLine(nameValue + " is " + j);

                                }
                                else
                                {
                                    string lineOne = sr.ReadLine();
                                    lineOne = sr.ReadLine();
                                    lineOne = sr.ReadLine();
                                    Console.WriteLine(nameValue + " is " + sr.ReadLine());
                                }



                            }
                            else
                            {
                                int x = 15;
                                int y = nameValue.Length;
                                int z = locationValue.Length;

                                int length = x + y + z;

                                sw.WriteLine("POST / HTTP/1.1");
                                sw.WriteLine("Host: " + host);
                                sw.WriteLine("Content-Length: " + length);
                                sw.WriteLine();
                                sw.WriteLine("name=" + nameValue + "&location=" + locationValue);

                                String reply = sr.ReadLine();
                                if (reply.EndsWith("OK"))
                                {
                                    Console.WriteLine(nameValue + " location changed to be " + locationValue + "\r\n");
                                }
                                else
                                {
                                    Console.WriteLine("ERROR: Unexpected response: " + reply);
                                }

                            }
                            break;
                    }
                }

                catch (Exception e)
                {
                    Console.WriteLine(e + "\r\n" + "An error has occurred");

                }
                return 0;
            }
            else
            {
                FreeConsole();
                var app = new App();
                return app.Run();
            }
        }
    }
}









